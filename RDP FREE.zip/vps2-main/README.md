# RDP Windows Gratis 6 Jam

Buat RDP Windows Ram 7GB 2 Core Cpu Dengan Github:
+ Tekan Tombol Fork untuk membuat RDP (Bagi Pengguna Android/HP Disilahkan Pake Mode Desktop).
+ Kunjungi https://dashboard.ngrok.com untuk mendapatkan NGROK_AUTH_TOKEN
+ Di Dalam Repo ini Pergi ke Settings> Secrets> New repository secret
+ Isi Nama: Masukan NGROK_AUTH_TOKEN
+ Isi Value: Kunjungi https://dashboard.ngrok.com/auth/your-authtoken Copy Dan Paste di dalam Value
+ Tekan Add secret
+ Pergi Ke Action> CI> Run workflow
+ Refresh Web dan masuk ke CI> build
+ Tekan Tombol panah menghadap ke bawah "RDP INFO LOGIN" Untuk Mendapatkan IP, User, Password.
+ Login Ke RDP.
+ Tunggu Beberapa Menit.
+ Tekan Agree.
+ Selamat Anda Mendapatkan FreeRDP 6 Jam!

Kang Recode Script:
+ https://github.com/bangjackcreator/MBAHGADGET
+ https://github.com/AdityaGans2542/AdityaRDP

Preview:
+ [<img img alt="Preview" src="https://raw.githubusercontent.com/EmanSaputra/FreeRDP/main/preview.png"/>](https://github.com/EmanSaputra/FreeRDP)
